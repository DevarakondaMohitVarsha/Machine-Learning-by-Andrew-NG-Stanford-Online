function [J, grad] = costFunction(theta, X, y)
%COSTFUNCTION Compute cost and gradient for logistic regression
%   J = COSTFUNCTION(theta, X, y) computes the cost of using theta as the
%   parameter for logistic regression and the gradient of the cost
%   w.r.t. to the parameters.

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta.
%               You should set J to the cost.
%               Compute the partial derivatives and set grad to the partial
%               derivatives of the cost w.r.t. each parameter in theta
%
% Note: grad should have the same dimensions as theta
%

% Calculating cost function J(theta) 

	hx = X*theta;							%h(x) = theta' * x;
	gx = sigmoid(hx);						%g(x) = sigmoid function which calculates g(theta'*x)

	ln  = log(gx);
	ln1 = log(1-gx);

	cost = -y.*(ln)-(1-y).*(ln1);			%cost equation  -y*log(h(x))-(1-y)log(1-h(x))
	cost_sum=0;								

	for i = 1:m,
		cost_sum = cost_sum + cost(i);		%summing up cost for all values 
	end;

	J = cost_sum/m;							%finally dividing the total cost by number of training examples


% Calculating gradients

	temp = gx-y;								%sigmoid(h(x)-y)
	
	for j = 1:size(theta),
		for i = 1:m,
			grad(j) = grad(j)+temp(i)*(X(i,j));	%summation term 
		end;
	end;
	
	grad=grad./m;								%1/m of summation
	




% =============================================================

end
