function [J, grad] = costFunctionReg(theta, X, y, lambda)
%COSTFUNCTIONREG Compute cost and gradient for logistic regression with regularization
%   J = COSTFUNCTIONREG(theta, X, y, lambda) computes the cost of using
%   theta as the parameter for regularized logistic regression and the
%   gradient of the cost w.r.t. to the parameters. 

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta.
%               You should set J to the cost.
%               Compute the partial derivatives and set grad to the partial
%               derivatives of the cost w.r.t. each parameter in theta



% Calculating cost function J(theta) 

	%code for Left expression of the cost function 
	
		hx = X*theta;							%h(x) = theta' * x;
		gx = sigmoid(hx);						%g(x) = sigmoid function which calculates g(theta'*x)

		ln  = log(gx);
		ln1 = log(1-gx);

		cost = -y.*(ln)-(1-y).*(ln1);			%cost equation  -y*log(h(x))-(1-y)log(1-h(x))
		cost_sum=0;								

		for i = 1:m,
			cost_sum = cost_sum + cost(i);		%summing up cost for all values 
		end;

		J1 = cost_sum/m;							%finally dividing the total cost by number of training examples
				
	% code for Right Expression of the cost function
		
		theta_sq = theta .^2;
		
		t = sum(theta_sq(2:size(theta_sq)));
		
		J2 = t.*(lambda/(2*m));

	
	% final cost function is sum of left and right expressions
		
		J = J1+J2;
		
		
		
		
% Calculating gradients
	
	% code for Left expression of the gradient
	
		temp = gx-y;								%sigmoid(h(x)-y)
		
		grad1 = zeros(size(theta));
		
		
		
		for j = 1:size(theta),
			for i = 1:m,
				grad1(j) = grad1(j)+temp(i)*(X(i,j));	%summation term 
			end;
		end;
		
		grad1 = grad1./m;		%1/m of summation

	
	% code for Right expression of the gradient
		
		grad2 = theta(2:size(theta,1)).*(lambda/m);
		grad2 = [0;grad2];		%appending an extra zero to balence dimensions and
								%also because we ignore 1st theta  and calculate all next theta values

	% final gradient function is sum of left and right expressions
		
		grad = grad1 + grad2;


% =============================================================

end
