function J = computeCost(X, y, theta)
%COMPUTECOST Compute cost for linear regression
%   J = COMPUTECOST(X, y, theta) computes the cost of using theta as the
%   parameter for linear regression to fit the data points in X and y

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta
%               You should set J to the cost.

hx = X*theta;  %predictions matrix

temp = (hx-y).^2; % temp vector holds calculated value of the part (hx(i)-y(i))^2 of J(theta) equation

temp1 = 0.0;	% initilization of temporary value to zero 

for i  = 1:m,
	temp1 = temp1 + temp(i);     % this computes upto the summation part of J(theta) equation 
end;							 % i.e, Sigma i = 1 to m {(hx(i)-y(i))^2}

J = temp1/(2*m);				 % finally we return the value of J(theta) by dividing the above result by 2*m
	


% =========================================================================

end
